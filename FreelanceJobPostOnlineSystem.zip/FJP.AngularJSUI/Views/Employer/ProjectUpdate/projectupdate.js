﻿appEIS.controller('projrectUpdateController', function ($scope) {
    $scope.msg = "Welcome To Project Update";
});