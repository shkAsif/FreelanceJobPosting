﻿appEIS.factory('projectMgmtService', function($http) {
    empMgmtObj = {};

    empMgmtObj.getAll = function() {
        var Emps;

        //  Emps = $http({ method: 'Get', url:$rootScope.ServiceUrl+ 'Employee' }).
        Emps = $http({ method: 'Get', url: 'http://localhost:18911/api/Employer' }).
            then(function(response) {
                return response.data;
            });

        return Emps;
    };

    empMgmtObj.createEmployer = function (emp) {
        var Emp;

        Emp = $http({ method: 'Post', url: 'http://localhost:18911/api/Employer', data: emp }).
        then(function (response) {

            return response.data;

        }, function (error) {
            return error.data;
        });

        return Emp;
    };
    
    return empMgmtObj;

});



appEIS.controller('projectMgmtController', function ($scope, projectMgmtService, utilityService) {
    $scope.msg = "Welcome To Project Managment";

    projectMgmtService.getAll().then(function (result) {
        $scope.Emps = result;
    });

    $scope.Sort = function (col) {
        $scope.key = col;
        $scope.AscOrDesc = !$scope.AscOrDesc;
    };


    $scope.CreateEmployer = function (Emp) {

        //debugger;

        //$scope.Emp.Password = Math.random().toString(36).substr(2, 5);
        $scope.Emp.Password = utilityService.randomPassword();
        projectMgmtService.createEmployer(Emp).then(function(result) {
            $scope.Msg = " You have successfully created " + result.ProjectId;
            $scope.Flg = true;
            projectMgmtService.getAll().then(function(result) {
                $scope.Emps = result;
            });
            utilityService.myAlert();
       
        });

    };
    
});