﻿appEIS.controller('homeController', function ($scope) {
    $scope.msg = "Welcome To home";
});