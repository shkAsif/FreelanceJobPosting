﻿appEIS.controller('loginController', function ($scope) {
    $scope.msg = "Welcome To Login";
});