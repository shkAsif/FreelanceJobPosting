﻿appEIS.controller('recoverPasswordController', function ($scope) {
    $scope.msg = "Welcome To Recover Password";
});