﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FJP.DAL;
using FJP.BOL;

namespace FJP.BLL
{
    public class EmployerBs
    {
        private EmployerDb ObjDb;
        
        public List<string> Errors = new List<string>();

        public EmployerBs()
        {
            ObjDb = new EmployerDb();
        }
        public IEnumerable<Employer> GetALL()
        {
            return ObjDb.GetALL();
        }
        public Employer GetByID(string Id)
        {
            return ObjDb.GetByID(Id);
        }

        public bool Insert(Employer emp)
        {
            if (IsValidOnInsert(emp))
            {
                ObjDb.Insert(emp);
                //string subject = "Your Login Credentials On FJP";
                //string body = "User Name : " + emp.ProjectName  + "\n" +
                //             "Password : " + emp.Password + "\n" +
                //             "Regards," + "\n" +
                //             "Asif";
                //Utility.SendEmail(emp.ProjectName , subject, body);
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Delete(string Id)
        {
            ObjDb.Delete(Id);
        }
        public bool Update(Employer emp)
        {
            if (IsValidOnUpdate(emp))
            {
                ObjDb.Update(emp);
                return true;
            }
            else
            {
                return false;
            }
        }
        public Employer GetByProjectName(string projectname)
        {
            return ObjDb.GetByProjectName(projectname);
        }
       // public Employer RecoverPasswordByEmail(string projectname)
        //{
           // var emp = ObjDb.GetByProjectName(projectname);
            //if (emp != null)
            //{
            //    string subject = "Your Login Credentials On FJP";
            //    string body = "User Name : " + emp.ProjectName + "\n" +
            //                 "Password : " + emp.Password + "\n" +
            //                 "Regards," + "\n" +
            //                 "Asif";
            //    Utility.SendEmail(emp.ProjectName, subject, body);
            //}
            //return emp;
        //}

        public bool IsValidOnInsert(Employer emp)
        {
            //EmployerBs employeeObjBs = new EmployerBs();

            //Unique Project Id Validation
            //string ProjectIdValue = emp.ProjectId.ToString();
            //int count = employeeObjBs.GetALL().Where(x => x.ProjectId == ProjectIdValue).ToList().Count();
            //if (count != 0)
            //{
            //    Errors.Add("ProjectId Already Exist");
            //}

            //Unique Email Validation
            //string ProjectValue = emp.ProjectName.ToString();
            //count = employeeObjBs.GetALL().Where(x => x.ProjectName == ProjectValue).ToList().Count();
            //if (count != 0)
            //{
            //    Errors.Add("Project Name Already Exist");
            //}

            //if (Errors.Count() == 0)
                return true;
            //else
            //    return false;
        }

        public bool IsValidOnUpdate(Employer emp)
        {

            //Total Exp should be greater than Relevant Exp
          // var ProjectCostValue = emp.ProjectCost;
           // var RelevantExpValue = emp.RelevantExp;

            //if (0 > ProjectCostValue)
            //{
            //    Errors.Add("Project Cost should be greater than zero");
            //}

            //if (Errors.Count() == 0)
                return true;
           // else
             //   return false;
        }
    }
}
