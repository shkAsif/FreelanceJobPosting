﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FJP.BOL
{

    [Table("Employer")]
    public partial class Employer
    {
        public Employer()
        {
            RoleId = 2; // by default its a user role
            CreatedDate = DateTime.Now;
            ProjectCost = 10;

        }
        [Key]
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string ProjectId { get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(50)]
        [Required]
        public string ProjectName { get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(50)]
        [Required]
        public string Password { get; set; }

        [NotMapped]
        public string ConfirmPassword { get; set; }



        public double? ProjectCost { get; set; }

        public int RoleId { get; set; }
        public DateTime CreatedDate { get; set; }

        [ForeignKey("RoleId")]
        public virtual Role Role { get; set; }
    }


}

