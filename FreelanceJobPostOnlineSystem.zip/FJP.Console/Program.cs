﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FJP.BLL;
using FJP.BOL;
//using FJP.DAL;

namespace FJP.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            //Testing BAL
            //RoleDb R = new RoleDb();
            //R.Insert(new Role() {RoleName="Admin",RoleCode ="A" });
            //R.Save();

            //Testing BLL
            RoleBs R = new RoleBs();
            R.Insert(new Role() {RoleName="User",RoleCode ="U" });
           
        }
    }
}
