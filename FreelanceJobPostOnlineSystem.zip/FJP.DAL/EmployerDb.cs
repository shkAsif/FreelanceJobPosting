﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FJP.BOL;

namespace FJP.DAL
{
  public  class EmployerDb
    {
        private FJPDBContext db;
        public EmployerDb()
        {
            db = new FJPDBContext();
        }
        public IEnumerable<Employer> GetALL()
        {
            return db.Employers.ToList();
        }
        public Employer GetByID(string Id)
        {
            return db.Employers.Find(Id);
        }
        public void Insert(Employer emp)
        {
            db.Employers.Add(emp);
            Save();
        }
        public void Delete(string Id)
        {
            Employer emp = db.Employers.Find(Id);
            db.Employers.Remove(emp);
            Save();
        }
        public void Update(Employer emp)
        {
            db.Entry(emp).State = EntityState.Modified;
            db.Configuration.ValidateOnSaveEnabled = false;
            Save();
            db.Configuration.ValidateOnSaveEnabled = true;
        }

        public Employer GetByProjectName(string projectname)
        {
            return db.Employers.Where(x => x.ProjectName == projectname).FirstOrDefault();
        }

        public void Save()
        {
            db.SaveChanges();
        }

    }
}
