﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FJP.DAL
{
    class DALBase
    {

        protected FJPDBContext db;

        public DALBase()
        {
            db = new FJPDBContext();
        }

    }
}
