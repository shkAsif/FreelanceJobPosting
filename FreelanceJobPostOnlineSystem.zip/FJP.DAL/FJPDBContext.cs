﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using FJP.BOL;

namespace FJP.DAL
{
    class FJPDBContext : DbContext
    {


        public FJPDBContext():base("FJPDB")
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<FJPDBContext, FJP.DAL.Migrations.Configuration>());
            Configuration.ProxyCreationEnabled = false; // Stop looping into the relationship created between Role and Employer table.
        }

        public DbSet<Role> Roles { get; set; }
        public DbSet<Employer> Employers { get; set; }

        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Employee>().Property(p => p.Email).HasColumnAnnotation(IndexAnnotation.AnnotationName, new IndexAnnotation(new IndexAttribute() { IsUnique = true }));
        //}
    }
}
