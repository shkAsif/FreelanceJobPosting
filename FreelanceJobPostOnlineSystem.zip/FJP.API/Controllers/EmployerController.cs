﻿using FJP.BLL;
using FJP.BOL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Cors;

namespace FJP.API.Controllers
{
    [EnableCors("*", "*", "*")]
    public class EmployerController : ApiController
    {

        EmployerBs employerObjBs;

        public EmployerController()
        {
            employerObjBs = new EmployerBs();
        }

        [ResponseType(typeof(IEnumerable<Employer>))]
        public IHttpActionResult Get()
        {
            return Ok(employerObjBs.GetALL());
        }

        [ResponseType(typeof(Employer))]
        public IHttpActionResult Get(string id)
        {
            Employer employer = employerObjBs.GetByID(id);
            if (employer != null)
                return Ok(employer);
            else
                return NotFound();
        }

        [ResponseType(typeof(Employer))]
        public IHttpActionResult Post(Employer employer)
        {
            if (ModelState.IsValid)
            {
                employerObjBs.Insert(employer);
                return CreatedAtRoute("DefaultApi", new { id = employer.ProjectId }, employer);
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [ResponseType(typeof(Employer))]
        public IHttpActionResult Put(int id, Employer employer)
        {
            if (ModelState.IsValid)
            {
                employerObjBs.Update(employer);
                return Ok(employer);
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [ResponseType(typeof(Role))]
        public IHttpActionResult Delete(String id)
        {
            Employer employer = employerObjBs.GetByID(id);
            if (employer != null)
            {
                employerObjBs.Delete(id);
                return Ok(employer);
            }
            else
            {
                return NotFound();
            }
        }
    }



}

